*PADS-LIBRARY-PART-TYPES-V9*

PSR500HTQFH1L00 RESC15078X150N I RES 9 1 0 0 0
TIMESTAMP 2026.08.24.09.29.56
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" PSR500HTQFH1L00
"Mouser Part Number" 755-PSR500HTQFH1L00
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/PSR500HTQFH1L00?qs=493kPxzlxfK9LZdh5GjqNQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 15x7.75 (5931) size, 10W, 1m, High Power Type Metal Plate Shunt Resistor (AEC-Q200 Qualified)
"Datasheet Link" https://fscdn.rohm.com/en/products/databook/datasheet/passive/resistor/chip_resistor/psr-e.pdf
"Geometry.Height" 1.5mm
GATE 1 2 0
PSR500HTQFH1L00
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
377505/261166/2.50/2/2/Resistor

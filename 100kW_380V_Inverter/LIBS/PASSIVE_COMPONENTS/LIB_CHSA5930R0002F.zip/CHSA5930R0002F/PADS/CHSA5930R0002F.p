*PADS-LIBRARY-PART-TYPES-V9*

CHSA5930R0002F CHSA5930R0002F I IND 9 1 0 0 0
TIMESTAMP 2026.08.24.09.39.45
"Manufacturer_Name" Eaton
"Manufacturer_Part_Number" CHSA5930R0002F
"Mouser Part Number" 504-CHSA5930R0002F
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bussmann-Eaton/CHSA5930R0002F?qs=By6Nw2ByBD3V6hwBz5yxEg%3D%3D
"Arrow Part Number" CHSA5930R0002F
"Arrow Price/Stock" https://www.arrow.com/en/products/chsa5930r0002f/eaton?utm_currency=USD&region=nac
"Description" Current Sense Resistors - SMD CHS, 5930 SIZE, 15 Watt, 0.2 mohm, AEC-Q
"Datasheet Link" https://www.eaton.com/content/dam/eaton/products/electronic-components/resources/data-sheet/eaton-chsa-automotive-smd-current-sense-resistor-metal-shunt-data-sheet-elx1223-en.pdf
"Geometry.Height" 1.93mm
GATE 1 2 0
CHSA5930R0002F
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17037783/261166/2.50/2/3/Inductor

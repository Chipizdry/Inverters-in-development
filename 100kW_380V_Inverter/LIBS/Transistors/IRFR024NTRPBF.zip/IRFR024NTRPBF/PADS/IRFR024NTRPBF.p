*PADS-LIBRARY-PART-TYPES-V9*

IRFR024NTRPBF IRFR024NTRPBF I TRX 9 1 0 0 0
TIMESTAMP 2026.06.18.12.01.57
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" IRFR024NTRPBF
"Mouser Part Number" 942-IRFR024NTRPBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/IRFR024NTRPBF?qs=9%252BKlkBgLFf35AlyEbDFeFQ%3D%3D
"Arrow Part Number" IRFR024NTRPBF
"Arrow Price/Stock" https://www.arrow.com/en/products/irfr024ntrpbf/infineon-technologies-ag?utm_currency=USD&region=nac
"Description" 55V Single N-Channel IR MOSFET in a D-Pak package
"Datasheet Link" https://www.infineon.com/cms/en/product/power/mosfet/n-channel/irfr024n/
"Geometry.Height" 2.52mm
GATE 1 3 0
IRFR024NTRPBF
1 0 U G
2 0 U D
3 0 U S

*END*
*REMARK* SamacSys ECAD Model
760948/261166/2.50/3/3/MOSFET (N-Channel)
